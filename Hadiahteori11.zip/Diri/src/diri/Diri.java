/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diri;
import java.awt.*;

public class Diri extends Panel {
    Diri() {
        setBackground(Color.WHITE);
    }
        public void paint(Graphics g){
            //rambut
            g.setColor(new Color(45, 30, 11));
            g.drawOval(100,20,75,75);
            g.fillOval(100,20,75,75);
            g.fillRect(100,60,75,75);
            
            //leher
            g.setColor(new Color(235, 208, 173));
            g.fillRect(125,90,20,45);
            
            //muka
            g.setColor(new Color(235, 208, 173));
            g.fillOval(100, 40,75,75);
            g.setColor(Color.BLACK);
            g.drawOval(100, 40,75,75);
            
            //poni
            g.setColor(new Color(45, 30, 11));
            int[] x2 = {100,120,150,170,180, 170, 130, 100};
            int[] y2 = {50 , 40, 30, 40,50, 90, 60 , 100};
            Polygon pol2= new Polygon(x2, y2, 8);
            g.fillPolygon(pol2);
            
            //tangan
            g.setColor(new Color(235, 208, 173));
            int[] x1 = {180,220,210,175};
            int[] y1 = {145,170,180,155};
            Polygon pol1 = new Polygon(x1, y1, 4);
            g.fillPolygon(pol1);
            int[] x4 = {75 , 50, 60, 90};
            int[] y4 = {150,170,180,155};
            Polygon pol4 = new Polygon(x4, y4, 4);
            g.fillPolygon(pol4);
            
            //baju
            g.setColor(new Color(6, 26, 45));
            int[] x3 = {100, 170,200,185,170, 170,100,100, 85, 70};
            int[] y3 = {135, 135,150,170,150, 210,210,150,170,150};
            Polygon pol3 = new Polygon(x3, y3, 10);
            g.fillPolygon(pol3);
            
            //celana
            g.setColor(new Color(18, 13, 2));
            g.fillRect(100,210,70,70);
            
            //mata
            g.setColor(Color.BLACK);
            g.fillOval(115,75,10,10);
            g.fillOval(150,75,10,10);
           
        }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Gambar diri");
        Diri d = new Diri();
        f.add(d);
        f.setSize(400,500);
        f.setVisible(true);
    }
    
}
